void cdargument(char * cdcommand,char *pwd);
