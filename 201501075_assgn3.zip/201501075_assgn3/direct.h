void direct(char *argument[],int start);
