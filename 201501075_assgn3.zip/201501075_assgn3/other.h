void otherargument(char * othercommand[]);
