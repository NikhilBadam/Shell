void insertpid(char arr[],int id);
void deletepid(int id);
void jobs();
void kjob(char *argument[]);
int getpi(int job);
void fg(char *argument[]);
void killall();
