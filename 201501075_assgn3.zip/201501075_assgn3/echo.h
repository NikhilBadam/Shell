void echoargument(char * echocommand[],int i);
