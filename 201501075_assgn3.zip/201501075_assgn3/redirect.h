void redirect(char *argument[]);
