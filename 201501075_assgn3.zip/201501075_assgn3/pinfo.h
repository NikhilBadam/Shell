void pinfoargument(char *argument[],int num,char pwd[]);
