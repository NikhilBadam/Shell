void pipe1(char *argument[],int check);
